"""
NETFLIX DATA ANALYSIS USING PYTHON
Complete project script

Dataset source:
https://raw.githubusercontent.com/japnitahuja/netflix-data-analysis/main/netflix_titles.csv

The script downloads the public Netflix titles dataset, cleans it,
creates analysis-ready columns, generates charts, and exports results.
"""

import warnings
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

warnings.filterwarnings("ignore")

BASE = Path(".")
OUTPUT = BASE / "netflix_project_output"
OUTPUT.mkdir(exist_ok=True)

DATA_URL = "https://raw.githubusercontent.com/japnitahuja/netflix-data-analysis/main/netflix_titles.csv"

# ------------------------------------------------------------
# 1. IMPORT DATA
# ------------------------------------------------------------
df = pd.read_csv(DATA_URL)

print("=" * 70)
print("NETFLIX DATA ANALYSIS")
print("=" * 70)
print("Original shape:", df.shape)
print("\nColumns:")
print(df.columns.tolist())

# ------------------------------------------------------------
# 2. DATA UNDERSTANDING
# ------------------------------------------------------------
print("\n--- DATA TYPES ---")
print(df.dtypes)

print("\n--- MISSING VALUES ---")
missing = df.isna().sum().sort_values(ascending=False)
print(missing)

print("\n--- DUPLICATES ---")
print("Duplicate rows:", df.duplicated().sum())

print("\n--- SUMMARY ---")
print(df.describe(include="all").transpose().head(20))

# ------------------------------------------------------------
# 3. DATA CLEANING
# ------------------------------------------------------------
clean = df.copy()

# Remove exact duplicate rows.
clean = clean.drop_duplicates().copy()

# Standardize text columns.
text_cols = ["type", "title", "director", "cast", "country", "rating", "duration", "listed_in", "description"]
for col in text_cols:
    if col in clean.columns:
        clean[col] = clean[col].astype("string").str.strip()

# Standardize Type values.
clean["type"] = clean["type"].replace({"movie": "Movie", "tv show": "TV Show"})

# Fill descriptive missing values without inventing specific people/countries.
for col in ["director", "cast", "country"]:
    clean[col] = clean[col].fillna("Unknown")

# Date conversion.
clean["date_added"] = pd.to_datetime(clean["date_added"], errors="coerce")
clean["year_added"] = clean["date_added"].dt.year
clean["month_added"] = clean["date_added"].dt.month_name()

# Rating and duration missing values.
clean["rating"] = clean["rating"].fillna("Unknown")
clean["duration"] = clean["duration"].fillna("Unknown")

# Extract numeric duration.
clean["duration_value"] = pd.to_numeric(
    clean["duration"].str.extract(r"(\d+)")[0], errors="coerce"
)

clean["duration_unit"] = np.select(
    [
        clean["duration"].str.contains("min", case=False, na=False),
        clean["duration"].str.contains("Season", case=False, na=False),
    ],
    ["Minutes", "Seasons"],
    default="Unknown"
)

# Helpful categorical features.
clean["primary_genre"] = clean["listed_in"].str.split(",").str[0].str.strip()
clean["primary_country"] = clean["country"].str.split(",").str[0].str.strip()

# ------------------------------------------------------------
# 4. EXPORT CLEANED DATA
# ------------------------------------------------------------
clean.to_csv(OUTPUT / "netflix_cleaned.csv", index=False)

# ------------------------------------------------------------
# 5. ANALYSIS
# ------------------------------------------------------------
type_counts = clean["type"].value_counts()
rating_counts = clean["rating"].value_counts().head(10)
country_counts = (
    clean.loc[clean["primary_country"] != "Unknown", "primary_country"]
    .value_counts()
    .head(10)
)
genre_counts = clean["primary_genre"].value_counts().head(10)

movie_df = clean[clean["type"] == "Movie"].copy()
tv_df = clean[clean["type"] == "TV Show"].copy()

# Tables
type_counts.rename("count").to_csv(OUTPUT / "content_type_summary.csv")
rating_counts.rename("count").to_csv(OUTPUT / "top_ratings.csv")
country_counts.rename("count").to_csv(OUTPUT / "top_countries.csv")
genre_counts.rename("count").to_csv(OUTPUT / "top_genres.csv")

# ------------------------------------------------------------
# 6. VISUALIZATIONS
# ------------------------------------------------------------
sns.set_theme(style="whitegrid")

plt.figure(figsize=(8, 5))
type_counts.plot(kind="bar")
plt.title("Netflix Content by Type")
plt.xlabel("Content Type")
plt.ylabel("Number of Titles")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(OUTPUT / "01_content_type.png", dpi=160)
plt.close()

plt.figure(figsize=(10, 5))
clean["release_year"].value_counts().sort_index().plot()
plt.title("Netflix Titles by Release Year")
plt.xlabel("Release Year")
plt.ylabel("Number of Titles")
plt.tight_layout()
plt.savefig(OUTPUT / "02_release_year.png", dpi=160)
plt.close()

plt.figure(figsize=(10, 5))
rating_counts.sort_values().plot(kind="barh")
plt.title("Top Netflix Ratings")
plt.xlabel("Number of Titles")
plt.ylabel("Rating")
plt.tight_layout()
plt.savefig(OUTPUT / "03_ratings.png", dpi=160)
plt.close()

plt.figure(figsize=(10, 5))
country_counts.sort_values().plot(kind="barh")
plt.title("Top Production Countries")
plt.xlabel("Number of Titles")
plt.ylabel("Country")
plt.tight_layout()
plt.savefig(OUTPUT / "04_countries.png", dpi=160)
plt.close()

plt.figure(figsize=(10, 5))
genre_counts.sort_values().plot(kind="barh")
plt.title("Top Genres")
plt.xlabel("Number of Titles")
plt.ylabel("Genre")
plt.tight_layout()
plt.savefig(OUTPUT / "05_genres.png", dpi=160)
plt.close()

movie_minutes = movie_df.loc[movie_df["duration_unit"] == "Minutes", "duration_value"].dropna()
if len(movie_minutes):
    plt.figure(figsize=(9, 5))
    plt.hist(movie_minutes, bins=25)
    plt.title("Movie Duration Distribution")
    plt.xlabel("Minutes")
    plt.ylabel("Number of Movies")
    plt.tight_layout()
    plt.savefig(OUTPUT / "06_movie_duration.png", dpi=160)
    plt.close()

if clean["year_added"].notna().any():
    added_by_year = clean["year_added"].value_counts().sort_index()
    plt.figure(figsize=(10, 5))
    added_by_year.plot(kind="line", marker="o")
    plt.title("Titles Added to Netflix by Year")
    plt.xlabel("Year Added")
    plt.ylabel("Number of Titles")
    plt.tight_layout()
    plt.savefig(OUTPUT / "07_titles_added_by_year.png", dpi=160)
    plt.close()

# ------------------------------------------------------------
# 7. REPORTING
# ------------------------------------------------------------
print("\n--- KEY RESULTS ---")
print("Cleaned shape:", clean.shape)
print("\nContent type:")
print(type_counts)
print("\nTop ratings:")
print(rating_counts)
print("\nTop countries:")
print(country_counts)
print("\nTop genres:")
print(genre_counts)

if len(movie_minutes):
    print("\nAverage movie duration (minutes):", round(movie_minutes.mean(), 2))
    print("Median movie duration (minutes):", round(movie_minutes.median(), 2))

print("\nFiles exported to:", OUTPUT.resolve())
print("Project completed successfully.")
